package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import com.example.sandbox.CodeExecutionResult
import com.example.ui.components.SafetyShieldBadge
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekGreen
import com.example.ui.theme.SleekOnPrimaryContainer
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSurface
import com.example.ui.theme.SleekSurfaceVariant
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary

@Composable
fun SandboxScreen(
    lastResult: CodeExecutionResult?,
    onRunCode: (code: String, lang: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var codeInput by remember {
        mutableStateOf(
            "// Phoenix Safe Sandboxed Code Runner\n" +
                    "val a = 12\n" +
                    "val b = 5\n" +
                    "println(\"Computing hypotenuse:\")\n" +
                    "sqrt(pow(a, 2) + pow(b, 2))"
        )
    }
    var selectedLanguage by remember { mutableStateOf("kotlin") }

    val kotlinTemplates = listOf(
        "Math & Trig" to "val angle = pi / 4\nround(sin(angle) * 100) / 100",
        "Array Ops" to "listOf(42, 11, 88, 3, 99, 14).sorted()",
        "Loops & Print" to "repeat(4) {\n    println(\"Phoenix Step \$it\")\n}\n\"Completed successfully\"",
        "Geometry" to "val r = 7\nprintln(\"Circle Area with r=\$r:\")\npi * pow(r, 2)"
    )
    val webTemplates = listOf(
        "Landing Page" to (
            "<!DOCTYPE html>\n<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                "<style>body{font-family:sans-serif;margin:0;background:#0F172A;color:#F1F5F9;text-align:center;padding:48px 20px}" +
                "h1{color:#60A5FA} button{background:#005FB0;color:white;border:none;padding:12px 24px;border-radius:10px;font-size:16px}</style>" +
                "</head><body><h1>Phoenix Website Generator</h1><p>Edit this markup, then tap Execute to preview.</p>" +
                "<button onclick=\"alert('Hello from Phoenix!')\">Click Me</button></body></html>"
            ),
        "Simple Card" to (
            "<!DOCTYPE html>\n<html><body style=\"font-family:sans-serif;background:#F3F4F9;padding:24px\">" +
                "<div style=\"background:white;border-radius:16px;padding:20px;max-width:360px;margin:auto;box-shadow:0 2px 8px rgba(0,0,0,0.1)\">" +
                "<h2 style=\"margin-top:0\">Card Title</h2><p>Some descriptive text goes here.</p></div></body></html>"
            )
    )
    val templates = if (selectedLanguage == "html") webTemplates else kotlinTemplates

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SleekBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Header
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekSurface),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SleekPrimaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = "Code Engine",
                        tint = SleekPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Phoenix Code Execution Sandbox",
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Pure on-device in-memory evaluation with exploit-proof isolation.",
                        color = SleekTextSecondary,
                        fontSize = 11.sp
                    )
                }
                SafetyShieldBadge("Zero-Exploit Safe")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Language toggle: Kotlin logic engine vs HTML website preview
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("kotlin" to "Kotlin Logic", "html" to "Website (HTML)").forEach { (value, label) ->
                val isSelected = selectedLanguage == value
                Surface(
                    color = if (isSelected) SleekPrimaryContainer else SleekSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) SleekPrimary else SleekBorder),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            selectedLanguage = value
                            codeInput = if (value == "html") webTemplates.first().second else kotlinTemplates.first().second
                        }
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = if (value == "html") Icons.Default.Language else Icons.Default.Code,
                            contentDescription = label,
                            tint = if (isSelected) SleekOnPrimaryContainer else SleekTextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = label,
                            color = if (isSelected) SleekOnPrimaryContainer else SleekTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Templates Row
        Text(
            text = "Code Templates:",
            color = SleekTextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            templates.forEach { (name, snippet) ->
                Surface(
                    color = SleekSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
                    modifier = Modifier.clickable { codeInput = snippet }
                ) {
                    Text(
                        text = name,
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Code Editor
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2430)),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = "Editor",
                            tint = Color(0xFF93C5FD),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (selectedLanguage == "html") "HTML / WEBSITE SOURCE" else "KOTLIN / LOGIC SCRIPT",
                            color = Color(0xFF93C5FD),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (selectedLanguage == "html") "Live preview" else "Max 5000 ops",
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = codeInput,
                    onValueChange = { codeInput = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = Color(0xFFF1F5F9),
                        unfocusedTextColor = Color(0xFFE2E8F0)
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("code_editor_field"),
                    minLines = 5,
                    maxLines = 12
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Run Button
        Button(
            onClick = {
                if (codeInput.isNotBlank()) {
                    onRunCode(codeInput, selectedLanguage)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = SleekPrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("run_code_button")
        ) {
            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.White)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                if (selectedLanguage == "html") "Render Website Preview" else "Execute in Sandbox",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Website Preview (shown only after running HTML/website code)
        if (lastResult?.htmlPreview != null) {
            WebPreviewCard(html = lastResult.htmlPreview)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Execution Results Terminal
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekSurface),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Console & Output",
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (lastResult != null) {
                        Surface(
                            color = if (lastResult.isSuccess) SleekGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${lastResult.executionTimeMs}ms",
                                color = if (lastResult.isSuccess) SleekGreen else Color.Red,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (lastResult != null) {
                    if (lastResult.stdout.isNotBlank()) {
                        Text(
                            text = "STDOUT:",
                            color = SleekTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SleekSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = lastResult.stdout,
                                color = SleekPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Text(
                        text = "RETURN VALUE:",
                        color = SleekTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SleekSurfaceVariant)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = lastResult.returnValue,
                            color = if (lastResult.isSuccess) SleekGreen else Color(0xFFDC2626),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (lastResult.errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ERROR: ${lastResult.errorMessage}",
                            color = Color(0xFFDC2626),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lastResult.securityBadge,
                        color = SleekGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SleekSurfaceVariant)
                            .padding(18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Press \"Execute in Sandbox\" to run code.",
                            color = SleekTextMuted,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

/**
 * Renders generated HTML/website markup in a sandboxed on-device WebView.
 * JavaScript is enabled only for in-page interactivity (buttons, simple
 * scripts) — no network/file access is granted, and the content is loaded
 * from a local string, never a remote URL.
 */
@Composable
fun WebPreviewCard(html: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SleekSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Website Preview",
                        tint = SleekPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Live Website Preview",
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Surface(
                    color = SleekGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Sandboxed",
                        color = SleekGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
            ) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                        }
                    },
                    update = { webView ->
                        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("web_preview")
                )
            }
        }
    }
}
