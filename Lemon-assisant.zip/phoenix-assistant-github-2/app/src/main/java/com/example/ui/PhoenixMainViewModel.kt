package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PhoenixApplication
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteEntity
import com.example.data.local.TaskExecutionEntity
import com.example.data.repository.PhoenixSettings
import com.example.device.SafeAction
import com.example.network.LlamaMessage
import com.example.sandbox.CodeExecutionResult
import com.example.service.PhoenixVoiceService
import com.example.voice.VoiceRecognitionManager
import com.example.voice.VoiceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder

enum class PhoenixTab {
    CHAT,
    TASKS,
    SANDBOX,
    HISTORY,
    SETTINGS
}

class PhoenixMainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PhoenixApplication
    private val repository = app.repository
    private val settingsRepo = app.settingsRepository
    private val safeActionExecutor = app.safeActionExecutor
    private val sandboxEngine = app.codeSandboxEngine
    private val llamaClient = app.llamaApiClient

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskExecutionEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<PhoenixSettings> = settingsRepo.settings

    private val _selectedTab = MutableStateFlow(PhoenixTab.CHAT)
    val selectedTab: StateFlow<PhoenixTab> = _selectedTab.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _lastSandboxResult = MutableStateFlow<CodeExecutionResult?>(null)
    val lastSandboxResult: StateFlow<CodeExecutionResult?> = _lastSandboxResult.asStateFlow()

    val voiceState: StateFlow<VoiceState> = app.voiceManager.voiceState
    val audioRms: StateFlow<Float> = app.voiceManager.audioRms
    val transcription: StateFlow<String> = app.voiceManager.transcription

    init {
        // Start background service if enabled in settings
        if (settings.value.backgroundServiceEnabled) {
            PhoenixVoiceService.startService(app)
        }
    }

    fun selectTab(tab: PhoenixTab) {
        _selectedTab.value = tab
    }

    fun startListening() {
        if (settings.value.backgroundServiceEnabled) {
            PhoenixVoiceService.startService(app)
        } else {
            app.voiceManager.startListening(
                continuous = settings.value.wakeWordEnabled,
                offlineOnly = settings.value.offlineVoiceOnly
            )
        }
    }

    fun stopListening() {
        app.voiceManager.stopListening()
    }

    fun triggerPushToTalk() {
        app.voiceManager.triggerManualListening()
    }

    fun sendUserMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return

        viewModelScope.launch {
            // 1. Record user message
            repository.insertMessage(
                ChatMessageEntity(
                    role = "user",
                    content = trimmed,
                    timestamp = System.currentTimeMillis()
                )
            )

            // 2. Check for direct local safe device action first
            val action = SafeAction.parseFromText(trimmed)
            if (action != null) {
                executeActionDirect(action, "CHAT_INPUT")
                return@launch
            }

            // 3. Online Llama Chat completion
            val currentSettings = settings.value
            if (currentSettings.apiKey.isBlank()) {
                repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = "I can execute device tasks directly! To enable general conversation and advanced reasoning with Llama, please add your API Key in Settings.\n\n" +
                                "Try asking me to:\n" +
                                "• \"Open spotify and play Stay by Justin Bieber\"\n" +
                                "• \"Open notepad and write buy eggs and milk\"\n" +
                                "• \"Search on google for Android Jetpack Compose\"\n" +
                                "• \"Run code 2 + 2 * 10\"",
                        timestamp = System.currentTimeMillis() + 50
                    )
                )
                return@launch
            }

            _isGenerating.value = true
            val history = chatMessages.value.takeLast(6).map {
                LlamaMessage(role = it.role, content = it.content)
            }

            val systemPrompt = "You are Phoenix, an intelligent AI mobile device assistant. " +
                    "Your wake word is 'Hey Phoenix'. You have device-level task execution capabilities and safe code execution. " +
                    "All voice processing on the device is completely offline and private. " +
                    "When the user requests device actions, output standard structured tags: " +
                    "[ACTION:OPEN_SPOTIFY query=\"...\"] or [ACTION:WRITE_NOTE title=\"...\" content=\"...\"] or " +
                    "[ACTION:SEARCH_GOOGLE query=\"...\"] or [ACTION:OPEN_APP app=\"...\"] or [ACTION:RUN_CODE lang=\"kotlin\"]...[/ACTION]. " +
                    "If asked to build, design, or generate a website, page, or web UI, respond with " +
                    "[ACTION:RUN_CODE lang=\"html\"]<full self-contained HTML with inline CSS/JS>[/ACTION] so it renders as a live preview. " +
                    "If asked to generate, create, or draw a picture or image, respond with [ACTION:GENERATE_IMAGE prompt=\"...\"] " +
                    "using a short, vivid description of the desired image as the prompt. " +
                    "If the user asks who created or made this app, say it was created by the Bytetitan team. " +
                    "Be smart, helpful, precise, and secure."

            val result = llamaClient.chat(
                baseUrl = currentSettings.apiBaseUrl,
                apiKey = currentSettings.apiKey,
                model = currentSettings.modelName,
                systemPrompt = systemPrompt,
                history = history,
                userMessage = trimmed
            )

            _isGenerating.value = false

            result.onSuccess { reply ->
                // Check if reply contains an action
                val actionFromLlama = parseActionFromLlama(reply)
                val msgId = repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = reply,
                        timestamp = System.currentTimeMillis() + 100,
                        actionType = actionFromLlama?.typeName,
                        actionPayload = reply
                    )
                )

                if (actionFromLlama != null) {
                    executeActionDirect(actionFromLlama, "CHAT_LLM")
                }
            }.onFailure { err ->
                repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = "Unable to connect to Llama API: ${err.message ?: "Connection error"}. Verify your API key and base URL in Settings.",
                        timestamp = System.currentTimeMillis() + 100
                    )
                )
            }
        }
    }

    private fun parseActionFromLlama(reply: String): SafeAction? {
        val spotifyRegex = Regex("""\[ACTION:OPEN_SPOTIFY query="([^"]+)"\]""")
        val spotifyMatch = spotifyRegex.find(reply)
        if (spotifyMatch != null) return SafeAction.OpenSpotify(spotifyMatch.groupValues[1])

        val searchRegex = Regex("""\[ACTION:SEARCH_GOOGLE query="([^"]+)"\]""")
        val searchMatch = searchRegex.find(reply)
        if (searchMatch != null) return SafeAction.SearchGoogle(searchMatch.groupValues[1])

        val noteRegex = Regex("""\[ACTION:WRITE_NOTE title="([^"]*)" content="([^"]+)"\]""")
        val noteMatch = noteRegex.find(reply)
        if (noteMatch != null) return SafeAction.OpenNotepadAndWrite(noteMatch.groupValues[1].ifBlank { "Quick Note" }, noteMatch.groupValues[2])

        val appRegex = Regex("""\[ACTION:OPEN_APP app="([^"]+)"\]""")
        val appMatch = appRegex.find(reply)
        if (appMatch != null) return SafeAction.OpenApp(appMatch.groupValues[1])

        val codeRegex = Regex("""\[ACTION:RUN_CODE lang="([^"]*)"]([\s\S]*?)\[/ACTION]""")
        val codeMatch = codeRegex.find(reply)
        if (codeMatch != null) return SafeAction.RunCode(codeMatch.groupValues[1], codeMatch.groupValues[2].trim())

        val imageRegex = Regex("""\[ACTION:GENERATE_IMAGE prompt="([^"]+)"\]""")
        val imageMatch = imageRegex.find(reply)
        if (imageMatch != null) return SafeAction.GenerateImage(imageMatch.groupValues[1])

        return null
    }

    fun executeActionDirect(action: SafeAction, source: String = "MANUAL") {
        viewModelScope.launch {
            if (action is SafeAction.GenerateImage) {
                val encodedPrompt = URLEncoder.encode(action.prompt, "UTF-8").replace("+", "%20")
                val imageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=896&height=896&nologo=true"
                repository.insertTask(
                    TaskExecutionEntity(
                        actionType = "GENERATE_IMAGE",
                        title = "Generated Image",
                        details = "Prompt: ${action.prompt}",
                        status = "SUCCESS",
                        triggerSource = source,
                        securityAudit = "PASSED_ZERO_EXPLOIT"
                    )
                )
                repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = "Here's your generated image for: \"${action.prompt}\"",
                        timestamp = System.currentTimeMillis() + 100,
                        actionType = "GENERATE_IMAGE",
                        actionPayload = imageUrl,
                        actionStatus = "SUCCESS"
                    )
                )
                return@launch
            }

            if (action is SafeAction.RunCode) {
                val res = sandboxEngine.execute(action.code, action.language)
                _lastSandboxResult.value = res
                repository.insertTask(
                    TaskExecutionEntity(
                        actionType = "RUN_CODE",
                        title = "Sandboxed Code Execution",
                        details = "Code returned: ${res.returnValue}\nStdout: ${res.stdout}",
                        status = if (res.isSuccess) "SUCCESS" else "FAILED",
                        triggerSource = source,
                        securityAudit = res.securityBadge
                    )
                )
                repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = "Executed in Sandbox (${res.executionTimeMs}ms):\n```\n${res.stdout.ifBlank { res.returnValue }}\n```",
                        timestamp = System.currentTimeMillis() + 100,
                        actionType = "RUN_CODE",
                        actionStatus = if (res.isSuccess) "SUCCESS" else "FAILED"
                    )
                )
                return@launch
            }

            val result = safeActionExecutor.execute(action, source)
            repository.insertTask(
                TaskExecutionEntity(
                    actionType = result.actionType,
                    title = result.title,
                    details = result.details,
                    timestamp = System.currentTimeMillis(),
                    status = if (result.success) "SUCCESS" else "FAILED",
                    triggerSource = source,
                    securityAudit = result.securityAudit
                )
            )

            repository.insertMessage(
                ChatMessageEntity(
                    role = "assistant",
                    content = "${result.title}\n${result.details}",
                    timestamp = System.currentTimeMillis() + 100,
                    actionType = result.actionType,
                    actionStatus = if (result.success) "SUCCESS" else "FAILED"
                )
            )
        }
    }

    fun runCodeInSandbox(code: String, lang: String = "kotlin") {
        viewModelScope.launch {
            val res = sandboxEngine.execute(code, lang)
            _lastSandboxResult.value = res
            repository.insertTask(
                TaskExecutionEntity(
                    actionType = "RUN_CODE",
                    title = "Code Execution (${res.executionTimeMs}ms)",
                    details = "Return: ${res.returnValue} | Output: ${res.stdout}",
                    status = if (res.isSuccess) "SUCCESS" else "FAILED",
                    triggerSource = "SANDBOX_UI",
                    securityAudit = res.securityBadge
                )
            )
        }
    }

    fun saveNote(title: String, content: String) {
        viewModelScope.launch {
            repository.insertNote(
                NoteEntity(
                    title = title.ifBlank { "Untitled Note" },
                    content = content,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    isVoiceCreated = false
                )
            )
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun clearTasks() {
        viewModelScope.launch {
            repository.clearTasks()
        }
    }

    fun updateApiKey(key: String) = settingsRepo.updateApiKey(key)
    fun updateBaseUrl(url: String) = settingsRepo.updateBaseUrl(url)
    fun updateModel(model: String) = settingsRepo.updateModel(model)
    fun setWakeWordEnabled(enabled: Boolean) {
        settingsRepo.setWakeWordEnabled(enabled)
        if (enabled) startListening() else stopListening()
    }
    fun setOfflineVoiceOnly(enabled: Boolean) = settingsRepo.setOfflineVoiceOnly(enabled)
    fun setBackgroundServiceEnabled(enabled: Boolean) {
        settingsRepo.setBackgroundServiceEnabled(enabled)
        if (enabled) {
            PhoenixVoiceService.startService(getApplication())
        } else {
            PhoenixVoiceService.stopService(getApplication())
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}
