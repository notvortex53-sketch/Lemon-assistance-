package com.example.network

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

interface LlamaApiInterface {
    @POST
    suspend fun createChatCompletion(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Body request: LlamaChatRequest
    ): Response<LlamaChatResponse>
}

class LlamaApiClient {
    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .apply {
            // Only log request/response traffic in debug builds, and never log
            // headers (that's where the Authorization: Bearer <api key> lives).
            // Logging BODY/HEADERS in a release build means anything that can
            // read Logcat can read the user's API key straight off the device.
            if (BuildConfig.DEBUG) {
                addInterceptor(HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                    redactHeader("Authorization")
                })
            }
        }
        .build()

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://api.groq.com/openai/v1/") // default base
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: LlamaApiInterface = retrofit.create(LlamaApiInterface::class.java)

    suspend fun chat(
        baseUrl: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<LlamaMessage>,
        userMessage: String
    ): Result<String> {
        return try {
            val endpoint = if (baseUrl.endsWith("/")) "${baseUrl}chat/completions" else "$baseUrl/chat/completions"
            val authHeader = if (apiKey.startsWith("Bearer ", ignoreCase = true)) apiKey else "Bearer $apiKey"

            val messages = mutableListOf<LlamaMessage>()
            if (systemPrompt.isNotBlank()) {
                messages.add(LlamaMessage(role = "system", content = systemPrompt))
            }
            messages.addAll(history.takeLast(10))
            messages.add(LlamaMessage(role = "user", content = userMessage))

            val request = LlamaChatRequest(
                model = model,
                messages = messages,
                temperature = 0.7,
                maxTokens = 2048
            )

            val response = apiService.createChatCompletion(endpoint, authHeader, request)
            if (response.isSuccessful) {
                val reply = response.body()?.choices?.firstOrNull()?.message?.content
                if (!reply.isNullOrBlank()) {
                    Result.success(reply)
                } else {
                    Result.failure(Exception("Received empty response from Llama model"))
                }
            } else {
                val errorBody = response.errorBody()?.string() ?: "HTTP ${response.code()}"
                Result.failure(Exception("Llama API Error (${response.code()}): $errorBody"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
