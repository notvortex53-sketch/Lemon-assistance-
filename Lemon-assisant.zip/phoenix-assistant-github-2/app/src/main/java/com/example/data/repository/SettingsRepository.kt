package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PhoenixSettings(
    val apiKey: String,
    val apiBaseUrl: String,
    val modelName: String,
    val wakeWordEnabled: Boolean,
    val offlineVoiceOnly: Boolean,
    val backgroundServiceEnabled: Boolean,
    val voiceFeedbackEnabled: Boolean
)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("phoenix_assistant_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_API_KEY = "llama_api_key"
        private const val KEY_BASE_URL = "llama_base_url"
        private const val KEY_MODEL = "llama_model"
        private const val KEY_WAKE_WORD = "wake_word_enabled"
        private const val KEY_OFFLINE_VOICE = "offline_voice_only"
        private const val KEY_BG_SERVICE = "background_service_enabled"
        private const val KEY_VOICE_FEEDBACK = "voice_feedback_enabled"

        const val DEFAULT_BASE_URL = "https://api.groq.com/openai/v1/"
        const val DEFAULT_MODEL = "openai/gpt-oss-120b"
        // Hardcoded on purpose: this repo is private, so the risk of bots
        // scraping a public repo for exposed keys doesn't apply here. Still
        // worth remembering: if this repo is ever made public, gets a
        // collaborator added, or gets forked, this key travels with it
        // (including in git history) - rotate it in your Groq dashboard if
        // that ever happens, since deleting the line later won't undo that.
        const val DEFAULT_API_KEY = "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"
    }

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<PhoenixSettings> = _settings.asStateFlow()

    private fun loadSettings(): PhoenixSettings {
        // Fall back to BuildConfig.LLAMA_API_KEY if configured in secrets/.env
        val initialKey = try {
            val buildKey = BuildConfig::class.java.getField("LLAMA_API_KEY").get(null) as? String
            if (!buildKey.isNullOrBlank() && buildKey != "YOUR_LLAMA_API_KEY") buildKey else DEFAULT_API_KEY
        } catch (_: Exception) {
            DEFAULT_API_KEY
        }

        val storedKey = prefs.getString(KEY_API_KEY, null)
        val finalApiKey = if (!storedKey.isNullOrBlank()) storedKey else initialKey

        val storedModel = prefs.getString(KEY_MODEL, null)
        val finalModel = if (!storedModel.isNullOrBlank() && storedModel != "llama-3.3-70b-versatile") {
            storedModel
        } else {
            DEFAULT_MODEL
        }

        return PhoenixSettings(
            apiKey = finalApiKey,
            apiBaseUrl = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL,
            modelName = finalModel,
            wakeWordEnabled = prefs.getBoolean(KEY_WAKE_WORD, true),
            offlineVoiceOnly = prefs.getBoolean(KEY_OFFLINE_VOICE, true),
            backgroundServiceEnabled = prefs.getBoolean(KEY_BG_SERVICE, true),
            voiceFeedbackEnabled = prefs.getBoolean(KEY_VOICE_FEEDBACK, true)
        )
    }

    fun updateApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
        _settings.value = _settings.value.copy(apiKey = key.trim())
    }

    fun updateBaseUrl(url: String) {
        val trimmed = url.trim()
        // Refuse plaintext http:// endpoints outright: the API key travels in
        // an Authorization header on every request, so an insecure endpoint
        // means the key (and every prompt) goes over the wire in the clear.
        val safe = if (trimmed.startsWith("http://", ignoreCase = true)) {
            trimmed.replaceFirst("http://", "https://", ignoreCase = true)
        } else {
            trimmed
        }
        val formatted = if (!safe.endsWith("/")) "$safe/" else safe
        prefs.edit().putString(KEY_BASE_URL, formatted).apply()
        _settings.value = _settings.value.copy(apiBaseUrl = formatted)
    }

    fun updateModel(model: String) {
        prefs.edit().putString(KEY_MODEL, model.trim()).apply()
        _settings.value = _settings.value.copy(modelName = model.trim())
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WAKE_WORD, enabled).apply()
        _settings.value = _settings.value.copy(wakeWordEnabled = enabled)
    }

    fun setOfflineVoiceOnly(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_OFFLINE_VOICE, enabled).apply()
        _settings.value = _settings.value.copy(offlineVoiceOnly = enabled)
    }

    fun setBackgroundServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BG_SERVICE, enabled).apply()
        _settings.value = _settings.value.copy(backgroundServiceEnabled = enabled)
    }

    fun setVoiceFeedbackEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_FEEDBACK, enabled).apply()
        _settings.value = _settings.value.copy(voiceFeedbackEnabled = enabled)
    }
}
